<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Billing extends CI_Controller {

	public function __construct() {
		parent:: __construct();
		$this->load->library('session');
		$this->load->helper('form');
		$this->load->library('form_validation');
	}

	public function index()
	{
		if (!empty($this->session->userdata('userid')) && $this->session->userdata('usr_logged_in')==1 && $this->session->userdata('usergroup')==1)
		{

			//
		}
		else{
				redirect(base_url());
			}
	}

	public function onGetInvoiceView()
	{
		if (!empty($this->session->userdata('userid')) && $this->session->userdata('usr_logged_in')==1 && $this->session->userdata('usergroup')==1)
		{

			$Invdata = $this->bm->getInvList($p=null,$group_by='bill_no');
			if($Invdata){

				foreach ($Invdata as $key => $value) {
					$this->data['inv_data'][] = array(
						'inv_id' => $value->inv_id,
						'patient_name' => $value->patient_name,
						'doctor_name' => $value->doctor_name,
						'bill_no' => $value->bill_no,
						'group_id' => $value->group_id,
						'item_id' => $value->item_id,
						'price' => $value->price,
						'created_dtime' => $value->created_dtime
					);
				}
				
			//print_obj($this->data['inv_data']);die;
			}else{
				$this->data['inv_data']= '';
				
			}
			$this->load->view('billings/vw_invoices', $this->data, false);
		}
		else{
				redirect(base_url());
			}
	}


	public function onCreateInvoiceView()
	{
		if (!empty($this->session->userdata('userid')) && $this->session->userdata('usr_logged_in')==1 && $this->session->userdata('usergroup')==1)
		{

			findAlt:
			$this->data['billno'] = 'SUR-'.date('Y-m-d').'-'.random_strings(3);
			
			$invdata = $this->bm->getInvData($p=array('bill_no'=>$this->data['billno']),$many=TRUE);

			if(empty($invdata)){
				$this->load->view('billings/vw_invoices_craete', $this->data, false);
			}
			else{
				goto findAlt;
			}

			
		}
		else{
				redirect(base_url());
			}
	}

	public function onGetInvoiceDrops()
	{
		if (!empty($this->session->userdata('userid')) && $this->session->userdata('usr_logged_in')==1 && $this->session->userdata('usergroup')==1)
		{
			if($this->input->is_ajax_request() && $this->input->server('REQUEST_METHOD')=='POST'){

				
				$mode = xss_clean($this->input->post('mode'));

				if($mode=='get_item_name_by_group'){

					$group_id = xss_clean($this->input->post('group_id'));
					$item_data = $this->im->getItemData($p=array('group_id'=>$group_id),$many=TRUE);
					// print_obj($item_data);die;

					if($item_data){
						foreach ($item_data as $key => $value) {
							$return['itemdata'][] = array(
							'item_id'  => $value->item_id,
							'item_name'  => $value->item_name
							);
						}
					}
					else{
						$return['itemdata'] = '';
					}
				}

				elseif($mode=='get_item_rate_by_name'){

					$item_id = xss_clean($this->input->post('item_id'));
					$item_data = $this->im->getItemData($p=array('item_id'=>$item_id),$many=FALSE);
					// print_obj($item_data);die;

					if($item_data){
							$return['rate'] = $item_data->item_price;
					}
					else{
						$return['rate'] = '';
					}
				}
				
					
				header('Content-Type: application/json');

				echo json_encode($return);	
			}
			else{
				//exit('No direct script access allowed');
				redirect(base_url());
			}
		}else{
			redirect(base_url());
		}
	}

	public function onSetInvoice()
	{
		if (!empty($this->session->userdata('userid')) && $this->session->userdata('usr_logged_in')==1 && $this->session->userdata('usergroup')==1)
		{
			if($this->input->is_ajax_request() && $this->input->server('REQUEST_METHOD')=='POST'){

					$this->form_validation->set_rules('patient_name', 'Patient Name', 'trim|required|xss_clean|htmlentities');
					$this->form_validation->set_rules('doctor_name', 'Doctor Name', 'trim|required|xss_clean|htmlentities');
					$this->form_validation->set_rules('bill_no', 'Bill No', 'trim|required|xss_clean|htmlentities');
					$this->form_validation->set_rules('group_id', 'Group', 'trim|required|xss_clean|htmlentities');

					if ($this->form_validation->run() == FALSE)
					{
						$this->form_validation->set_error_delimiters('', '');
						$return['errors'] = validation_errors();
						$return['inv_added'] = 'rule_error';
					}
					else 
					{
						$patient_name = strip_tags($this->input->post('patient_name'));
						$doctor_name = strip_tags($this->input->post('doctor_name'));
						$bill_no = strip_tags($this->input->post('bill_no'));
						$discount = xss_clean($this->input->post('discount'));
						$str_group_id = xss_clean($this->input->post('group_id'));
						$str_item_id = xss_clean($this->input->post('item_id'));
						$str_price = xss_clean($this->input->post('price'));

						
						$group_id = explode(',',$str_group_id);
						$item_id = explode(',',$str_item_id);
						$price = explode(',',$str_price);
					
						for ($i=0; $i <=14 ; $i++) { 
							if($group_id[$i]!=0 && $group_id[$i]!='' && $item_id[$i]!=0 && $item_id[$i]!='' && $price[$i]!=0 && $price[$i]!='' && $price[$i]!='NaN'){

								$addData = array(
									'patient_name' => $patient_name,
									'doctor_name' => $doctor_name,
									'bill_no' => $bill_no,
									'group_id' => $group_id[$i],
									'item_id' => $item_id[$i],
									'price' => $price[$i],
									'created_dtime'  => dtime,
									'created_user'  => $this->session->userdata('userid')
								 );
								//print_obj($addData);
								$invAdded = $this->bm->addInvoice($addData);
								
							}
						}
						
						//die;

						if(isset($invAdded)){
							if($discount!=0 && $discount!='' && $discount!='NaN'){
									$addDis = array(
										'discount' => $discount,
										'bill_no' => $bill_no,
										'dtime'  => dtime
									);
									$invDiscount = $this->bm->addInvoiceDiscount($addDis);

									if($invDiscount){
										$return['inv_added'] = 'success';
									}
									else{
										$return['inv_added'] = 'failure';
									}
								}
								else{
									//no discount
									$return['inv_added'] = 'success';
								}
							}
						else{
								$return['inv_added'] = 'failure';
							}		
						
					
				}

				header('Content-Type: application/json');

				echo json_encode($return);	
			}	
			else{
				//exit('No direct script access allowed');
				redirect(base_url());
			}
		}else{
			redirect(base_url());
		}
	}

	public function onPrintInvoice()
	{
		if (!empty($this->session->userdata('userid')) && $this->session->userdata('usr_logged_in')==1 && $this->session->userdata('usergroup')==1)
		{
			$bill_no = xss_clean($this->uri->segment(2));

			$Invdata = $this->bm->getInvList($p=array('bill_no'=>$bill_no));
			if($Invdata){

				foreach ($Invdata as $key => $value) {
					$this->data['inv_data'][] = array(
						'inv_id' => $value->inv_id,
						'patient_name' => $value->patient_name,
						'doctor_name' => $value->doctor_name,
						'bill_no' => $value->bill_no,
						'group_id' => $value->group_id,
						'item_id' => $value->item_id,
						'item_name' => $value->item_name,
						'price' => $value->price,
						'created_dtime' => $value->created_dtime
					);
				}

			$sum_price = $this->bm->getInvSum($p=array('bill_no'=>$bill_no));
			//print_obj($sum_price);die;
			if(!empty($sum_price)){
				$this->data['grand_tot'] = $sum_price->tot_price;
			}
			else{
				$this->data['grand_tot'] = 0;
			}

			$discountData = $this->bm->getInvDiscountData($p=array('bill_no'=>$bill_no),$many=FALSE);
			if(!empty($discountData)){
				$this->data['dis_data'] = $discountData->discount;
			}
			else{
				$this->data['dis_data'] = 0;
			}
			
				
			//print_obj($this->data['user_data']);die;
			}else{
				$this->data['inv_data']= '';
				$this->data['dis_data']= '';
				
			}
			$this->load->view('billings/vw_print_invoice', $this->data, false);
		}
		else{
				redirect(base_url());
			}
	}

	public function onDeleteInvoice()
	{
		if (!empty($this->session->userdata('userid')) && $this->session->userdata('usr_logged_in')==1 && $this->session->userdata('usergroup')==1)
			{
			   if($this->input->is_ajax_request() && $this->input->server('REQUEST_METHOD')=='POST'){

				$invid = xss_clean($this->input->post('invid'));
				$billno = xss_clean($this->input->post('billno'));
				$invoiceData = $this->bm->getInvData(array('inv_id'  => $invid),$many=FALSE);

				if($invoiceData){
					//del
					$delinv = $this->bm->delInvoice(array('bill_no' => $billno));
					$delInvDis = $this->bm->delInvDisc(array('bill_no' => $billno));

					if($delinv && $delInvDis){
						$return['deleted'] = 'success';
					}
					else{
						$return['deleted'] = 'failure';
					}
						
				}
				else{
					$return['deleted'] = 'not_exists';
				}

			header('Content-Type: application/json');
			echo json_encode($return);	

			}else{
				redirect(base_url());
			}
		}
 	}
	




}