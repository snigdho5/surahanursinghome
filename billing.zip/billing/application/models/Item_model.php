<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *
 */
class Item_model extends MY_Model {


	function __construct(){
		//
	}
	

	public function addItem($data){
		$this->table='items';
		return $this->store($data);
	}
	public function getItemData($param=null,$many=FALSE){
		$this->table='items';
		if($param!=null && $many==FALSE){
			return $this->get_one($param);
		}
		elseif($param!=null && $many==TRUE){
			return $this->get_many($param,$order_by='item_id',$order='DESC',FALSE);
		}
		elseif($param==null && $many==TRUE){
			return $this->get_many($param=null,$order_by='item_id',$order='DESC',FALSE);
		}
		else{
			return $this->get_many();
		}
	}
	public function updateItem($data,$param){
		$this->table='items';
		return $this->modify($data,$param);
	}
	public function delItem($param){
		$this->table='items';
		return $this->remove($param);
	}


}
