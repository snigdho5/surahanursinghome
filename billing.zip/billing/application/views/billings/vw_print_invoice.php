<!DOCTYPE html>
<html>
<head>
<title>Suraha | Receipt</title>
<link rel="icon" type="image/png" sizes="16x16" href="<?php echo base_url().'common/assets/images/favicon.png';?>">
  <!--<style type="text/css" media="print">
  @page { 
        size: landscape;
    }
    body { 
        writing-mode: tb-rl;
    }
</style>-->
</head>
<body>
<center>
<h2 align="center"><a onClick="window.print();return false">Invoice Cum Money Receipt</a></h2>


        <table cellspacing="0" cellpadding="3" border="1" style="text-align:center;">
           <thead>
                   <?php if(!empty($inv_data)){?>
                    <tr>
                     <th scope="col"  colspan="2">Date: <span style="font-weight: normal;"><?php echo $inv_data[0]['created_dtime']; ?></span></th>
                     <th scope="col" colspan="2">Bill No: <span style="font-weight: normal;"><?php echo $inv_data[0]['bill_no']; ?></span></th>
                   </tr>
                    <tr>
                     <th scope="col"  colspan="2">Patient's Name: <span style="font-weight: normal;"></b><?php echo $inv_data[0]['patient_name']; ?></span></th>
                     <th scope="col"  colspan="2">Under Doctor: <span style="font-weight: normal;"><?php echo $inv_data[0]['doctor_name']; ?></span></th>
                   </tr>
                    <?php }  else{ ?>
                      <th  colspan="4"><button type="button" class="btn badge badge-pill badge-success" onclick="location.href='<?php echo base_url().'invoices'; ?>'">Invoices</button></th>
                        <?php } ?>
                  <tr class="textcen">
                    <th>Sl</th>
                    <th>Group</th>
                    <th>Items</th>
                    <th>Price</th>

                  </tr>
                  </thead>
                  <tbody class="textcen">
                  <?php
                  if(!empty($inv_data)){
                    //print_obj($inv_data);die;
                    $sl=1;
                    foreach($inv_data as $key => $val){
                      ?>
                      <tr>
                        <td><?php echo $sl; ?></td>
                        <td><?php
                          if($val['group_id']==1){
                            echo 'Blood';
                          }elseif($val['group_id']==2){
                            echo 'X-Ray';
                          }elseif($val['group_id']==3){
                            echo 'U.S.G.';
                          }else{
                            echo 'N/A';
                          }

                        ?></td>
                        <td><?php echo $val['item_name']; ?></td>
                        <td><?php echo $val['price']; ?></td>
                      </tr>
                      <?php
                      $sl++;
                    }
                    ?>
                    <tr style="text-align:center; font-size: 15px;">
                      <td colspan="2"></td><td><b>Discount:</b></td>
                      <td colspan="3"><?php echo $dis_data; ?></td>
                    </tr>
                    <tr style="text-align:center; font-size: 15px;">
                      
                      <td colspan="3"><b>Grand Total:</b></td>
                      <td><?php 
                        if($dis_data==0){
                            echo $grand_tot;
                        }else{
                          $final_gt = $grand_tot - $dis_data;
                          echo $final_gt;
                        }
                      
                       ?></td>
                    </tr>
                    <?php
                  }
                  else{
                    ?>
                    <tr><td colspan="6">No data found</td></tr>
                  <?php
                    }
                  ?>
                  </tbody>
        
           
       </table>
		<br /> <small align="center">This is a computer generated invoice, signature is not required.</small>
</center>
</body>
</html>	